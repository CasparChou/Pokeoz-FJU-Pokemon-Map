#!/usr/bin/env bash

sha256sum *.so *.dylib *.dll > SHA256SUMS
